"""Default (not specified) rss parser bot"""
from ..utils.rss_interface import BaseRssBot


class Bot(BaseRssBot):
    """Default (not specified) rss parser bot"""
    pass
