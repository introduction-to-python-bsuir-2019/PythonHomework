from rss_reader.rss import main
main()
