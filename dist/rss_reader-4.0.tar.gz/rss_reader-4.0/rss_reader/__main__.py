from rss_reader import rss
rss.main()
