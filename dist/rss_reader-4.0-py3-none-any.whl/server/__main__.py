from server import app
app.app.run(debug=True)