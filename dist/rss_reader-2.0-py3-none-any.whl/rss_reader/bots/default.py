from ..utils.RssInterface import BaseRssBot


class Bot(BaseRssBot):
    pass
